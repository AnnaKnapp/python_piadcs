# __init__.py
from .piadcs import *
# Version of pyADS1262
__version__ = "0.1.0"
