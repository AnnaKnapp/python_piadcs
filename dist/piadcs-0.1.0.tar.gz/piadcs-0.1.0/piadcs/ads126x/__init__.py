# __init__.py
from .ads126x import *
# Version of pyADS1262
__version__ = "0.1.0"
